# Hotspot Proxy

Прокси-сервер (HTTP + HTTPS/CONNECT) для Android. Соединения прокси создаёт само приложение,
поэтому при включённом VPN они идут через тоннель. Устройства, подключённые к вашей точке доступа,
указывают этот прокси вручную в настройках Wi-Fi.

## Сборка APK без Android Studio (GitHub Actions)
1. Создайте репозиторий на github.com.
2. Загрузите в него ВСЕ файлы проекта (включая папку `.github`): Add file → Upload files.
3. Вкладка Actions → «Build APK» → Run workflow (запустится и сам после загрузки).
4. Через ~5 минут откройте завершённый запуск → Artifacts → HotspotProxy-debug-apk.
5. Распакуйте архив и установите `app-debug.apk` (разрешите установку из неизвестных источников).

## Сборка в Android Studio
File → Open → папка проекта → Build → Build APK(s).
