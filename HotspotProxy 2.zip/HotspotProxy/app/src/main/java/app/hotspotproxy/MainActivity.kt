package app.hotspotproxy

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Collections

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var info: TextView
    private lateinit var portEdit: EditText
    private lateinit var btn: Button
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad, pad, pad)

        status = TextView(this)
        status.textSize = 22f

        portEdit = EditText(this)
        portEdit.inputType = InputType.TYPE_CLASS_NUMBER
        portEdit.setText("8888")
        portEdit.hint = "Порт"

        btn = Button(this)
        btn.setOnClickListener { toggle() }

        info = TextView(this)
        info.textSize = 15f
        info.setPadding(0, pad, 0, 0)

        root.addView(status)
        root.addView(portEdit)
        root.addView(btn)
        root.addView(info)

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun toggle() {
        if (ProxyService.running) {
            startService(Intent(this, ProxyService::class.java).setAction(ProxyService.ACTION_STOP))
        } else {
            val port = portEdit.text.toString().toIntOrNull()
            if (port == null || port < 1024 || port > 65535) {
                info.text = "Порт должен быть от 1024 до 65535"
                return
            }
            val i = Intent(this, ProxyService::class.java).putExtra(ProxyService.EXTRA_PORT, port)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        }
        handler.postDelayed({ refresh() }, 700)
    }

    private fun refresh() {
        val on = ProxyService.running
        status.text = if (on) "● Прокси включён" else "○ Прокси выключен"
        btn.text = if (on) "Остановить" else "Запустить"
        portEdit.isEnabled = !on

        val sb = StringBuilder()
        val err = ProxyService.lastError
        if (err != null) sb.append("Ошибка: ").append(err).append("\n\n")
        sb.append("Адреса телефона (нужен тот, что в сети раздачи, обычно ap0 / wlan1 / swlan0 и оканчивается на .1):\n")
        val addrs = localAddresses()
        if (addrs.isEmpty()) sb.append("— не найдены\n") else for (a in addrs) sb.append("• ").append(a).append('\n')
        sb.append(
            """

Как пользоваться:
1. Включите VPN speed cn.
2. Включите точку доступа Wi-Fi в настройках телефона.
3. Нажмите «Запустить» здесь.
4. На подключённом устройстве: Wi-Fi → ваша сеть → Прокси «Вручную» → адрес телефона из списка выше и порт.

Отключите для приложения оптимизацию батареи, иначе система может его остановить."""
        )
        info.text = sb.toString()
    }

    private fun localAddresses(): List<String> {
        val out = ArrayList<String>()
        try {
            val en = NetworkInterface.getNetworkInterfaces() ?: return out
            for (ni in Collections.list(en)) {
                if (!ni.isUp || ni.isLoopback) continue
                for (a in Collections.list(ni.inetAddresses)) {
                    if (a is Inet4Address) out.add(ni.name + ": " + a.hostAddress)
                }
            }
        } catch (e: Exception) {
        }
        return out
    }
}
