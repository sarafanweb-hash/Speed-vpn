package app.hotspotproxy

import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.URI
import java.util.Collections
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.concurrent.thread

/**
 * Простой HTTP/HTTPS (CONNECT) прокси.
 * Все исходящие соединения создаются из процесса этого приложения,
 * поэтому Android отправляет их в активный VPN-тоннель.
 */
class ProxyServer(private val port: Int) {

    private var server: ServerSocket? = null
    private val pool: ExecutorService = Executors.newCachedThreadPool()
    private val active: MutableSet<Socket> =
        Collections.newSetFromMap(ConcurrentHashMap<Socket, Boolean>())

    @Volatile
    private var running = false

    fun start() {
        val s = ServerSocket()
        s.reuseAddress = true
        s.bind(InetSocketAddress(port))
        server = s
        running = true
        thread(name = "proxy-accept", isDaemon = true) {
            while (running) {
                try {
                    val c = s.accept()
                    pool.execute { handle(c) }
                } catch (e: Exception) {
                    if (!running) break
                    try {
                        Thread.sleep(100)
                    } catch (ie: InterruptedException) {
                        break
                    }
                }
            }
        }
    }

    fun stop() {
        running = false
        try {
            server?.close()
        } catch (e: IOException) {
        }
        for (s in active.toList()) {
            try {
                s.close()
            } catch (e: IOException) {
            }
        }
        active.clear()
        pool.shutdownNow()
    }

    private fun handle(client: Socket) {
        active.add(client)
        var upstream: Socket? = null
        try {
            // Принимаем только клиентов из локальных сетей (точка доступа, USB, localhost)
            val ra = client.inetAddress
            if (ra == null || !(ra.isSiteLocalAddress || ra.isLinkLocalAddress || ra.isLoopbackAddress)) {
                return
            }

            client.tcpNoDelay = true
            client.soTimeout = 20000
            val cin = BufferedInputStream(client.getInputStream(), 8192)
            val cout = client.getOutputStream()

            val requestLine = readLine(cin) ?: return
            val parts = requestLine.split(" ")
            if (parts.size < 3) return
            val method = parts[0]
            val target = parts[1]
            val version = parts[2]

            val headers = ArrayList<String>()
            while (true) {
                val h = readLine(cin) ?: return
                if (h.isEmpty()) break
                headers.add(h)
            }

            val isConnect = method.equals("CONNECT", ignoreCase = true)
            val host: String
            val remotePort: Int
            var path = "/"

            if (isConnect) {
                val idx = target.lastIndexOf(':')
                host = (if (idx > 0) target.substring(0, idx) else target).trim('[', ']')
                remotePort = if (idx > 0) (target.substring(idx + 1).toIntOrNull() ?: 443) else 443
            } else {
                val uri = try {
                    URI(target)
                } catch (e: Exception) {
                    null
                }
                if (uri == null || uri.host == null) {
                    cout.write("HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n".toByteArray())
                    cout.flush()
                    return
                }
                host = uri.host.trim('[', ']')
                remotePort = if (uri.port == -1) 80 else uri.port
                path = uri.rawPath ?: ""
                if (path.isEmpty()) path = "/"
                val q = uri.rawQuery
                if (q != null) path = "$path?$q"
            }

            val u = Socket()
            upstream = u
            active.add(u)
            try {
                u.connect(InetSocketAddress(host, remotePort), 15000)
            } catch (e: IOException) {
                cout.write("HTTP/1.1 502 Bad Gateway\r\nConnection: close\r\n\r\n".toByteArray())
                cout.flush()
                return
            }
            u.tcpNoDelay = true

            if (isConnect) {
                cout.write("HTTP/1.1 200 Connection Established\r\n\r\n".toByteArray())
                cout.flush()
            } else {
                val sb = StringBuilder()
                sb.append(method).append(' ').append(path).append(' ').append(version).append("\r\n")
                for (h in headers) {
                    val name = h.substringBefore(':').trim().lowercase()
                    if (name == "proxy-connection" || name == "connection" ||
                        name == "proxy-authorization" || name == "keep-alive"
                    ) continue
                    sb.append(h).append("\r\n")
                }
                sb.append("Connection: close\r\n\r\n")
                val uout = u.getOutputStream()
                uout.write(sb.toString().toByteArray(Charsets.ISO_8859_1))
                uout.flush()
            }

            client.soTimeout = 0
            relay(client, cin, u)
        } catch (e: Exception) {
            // соединение оборвано — просто закрываем
        } finally {
            try {
                client.close()
            } catch (e: Exception) {
            }
            val u2 = upstream
            if (u2 != null) {
                try {
                    u2.close()
                } catch (e: Exception) {
                }
                active.remove(u2)
            }
            active.remove(client)
        }
    }

    private fun relay(client: Socket, cin: InputStream, upstream: Socket) {
        thread(name = "proxy-up", isDaemon = true) {
            copy(cin, upstream.getOutputStream())
            try {
                upstream.shutdownOutput()
            } catch (e: Exception) {
            }
        }
        copy(upstream.getInputStream(), client.getOutputStream())
    }

    private fun copy(i: InputStream, o: OutputStream) {
        val buf = ByteArray(16 * 1024)
        try {
            while (true) {
                val n = i.read(buf)
                if (n < 0) break
                o.write(buf, 0, n)
                o.flush()
            }
        } catch (e: IOException) {
        }
    }

    private fun readLine(i: InputStream): String? {
        val bo = ByteArrayOutputStream()
        while (true) {
            val b = i.read()
            if (b < 0) return if (bo.size() == 0) null else bo.toString("ISO-8859-1")
            if (b == '\n'.code) break
            if (b != '\r'.code) bo.write(b)
            if (bo.size() > 16384) return null
        }
        return bo.toString("ISO-8859-1")
    }
}
