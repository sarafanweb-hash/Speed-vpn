package app.hotspotproxy

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager

class ProxyService : Service() {

    companion object {
        const val ACTION_STOP = "app.hotspotproxy.STOP"
        const val EXTRA_PORT = "port"
        private const val CHANNEL = "proxy"
        private const val NOTIF_ID = 1

        @Volatile
        var running = false

        @Volatile
        var lastError: String? = null
    }

    private var server: ProxyServer? = null
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        val port = intent?.getIntExtra(EXTRA_PORT, 8888) ?: 8888
        goForeground(port)
        if (server != null) return START_NOT_STICKY

        try {
            val s = ProxyServer(port)
            s.start()
            server = s
            running = true
            lastError = null
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            val wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "hotspotproxy:srv")
            wl.acquire()
            wakeLock = wl
        } catch (e: Exception) {
            lastError = e.message ?: e.toString()
            running = false
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun goForeground(port: Int) {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Прокси", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, ProxyService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL)
        else Notification.Builder(this)
        val n = b.setContentTitle("Прокси для раздачи работает")
            .setContentText("Порт $port")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Стоп", stopIntent)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    override fun onDestroy() {
        server?.stop()
        server = null
        running = false
        val wl = wakeLock
        if (wl != null && wl.isHeld) wl.release()
        wakeLock = null
        super.onDestroy()
    }
}
